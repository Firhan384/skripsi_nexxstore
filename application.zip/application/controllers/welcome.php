<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {

	
	public function index()
	{
		$this->load->view('login');
	}

	public function form_daftar()
	{
		$this->load->view('daftar');
	}

	public function hal_beranda()
	{
		$this->load->view('beranda');
	}

	public function hal_material()
	{
		$this->data['hasil'] = $this->model_dis->getUser('stok_material');
		$this->load->view('material', $this->data);
	}

	public function input_material()
	{
		$id_prod = $_POST['id_prod'];
		$id_peng = $this->session->userdata('id_log');
		$nm_prod = $_POST['nm_produk'];
		$stok = $_POST['stok'];
		$satuan = $_POST['satuan'];
		$data = array('id_produk' => $id_prod, 'id_user' => $id_peng, 'nama_produk' => 		
					$nm_prod, 'stok' => $stok, 'satuan' => $satuan);
		$insert = $this->model_dis->tambah_user('stok_material', $data);
		if($insert > 0){			
			redirect('welcome/hal_material');
		}else{
			echo 'Gagal Input';
		}
	}

	public function update_material($id)
	{
		$id_prod = $_POST['id_prod'];
		$id_peng = $this->session->userdata('id_log');
		$nm_prod = $_POST['nm_produk'];
		$stok = $_POST['stok'];
		$satuan = $_POST['satuan'];
		$data = array('id_produk' => $id_prod, 'id_user' => $id_peng, 'nama_produk' => 		
					$nm_prod, 'stok' => $stok, 'satuan' => $satuan);
		$edit = $this->model_dis->editData('stok_material', $data,$id);
		if($edit > 0){			
			redirect('welcome/hal_material');
		}else{
			echo 'Gagal Input';
		}
	}

	public function hal_pemasok()
	{
		$this->data['hasil'] = $this->model_dis->getUser('pemasok');
		$this->load->view('pemasok', $this->data);
	}

	public function input_pemasok()
	{
		$id_pemasok = $_POST['id_pemasok'];
		$id_peng = $this->session->userdata('id_log');
		$nm_pemasok = $_POST['nm_pemasok'];
		$almt = $_POST['almt'];
		$email = $_POST['email'];
		$no_telp = $_POST['no_telp'];
		$data = array('id_pemasok' => $id_pemasok, 'id_user' => $id_peng, 'nama_pemasok' => 		
					$nm_pemasok, 'alamat' => $almt, 'email' => $email, 'no_telp' => $no_telp);
		$insert = $this->model_dis->tambah_user('pemasok', $data);
		if($insert > 0){
			redirect('welcome/hal_pemasok');
		}else{
			echo 'Gagal Input'; 
		}
	}

	public function update_pemasok($id)
	{
		$id_pemasok = $_POST['id_pemasok'];
		$id_peng = $this->session->userdata('id_log');
		$nm_pemasok = $_POST['nm_pemasok'];
		$almt = $_POST['almt'];
		$email = $_POST['email'];
		$no_telp = $_POST['no_telp'];
		$data = array('id_pemasok' => $id_pemasok, 'id_user' => $id_peng, 'nama_pemasok' => 		
					$nm_pemasok, 'alamat' => $almt, 'email' => $email, 'no_telp' => $no_telp);
		$edit = $this->model_dis->editData2('pemasok', $data,$id);
		if($edit > 0){
			redirect('welcome/hal_pemasok');
		}else{
			echo 'Gagal Input'; 
		}
	}

	public function hal_brg_jadi()
	{
		$this->data['hasil'] = $this->model_dis->getUser('stok_barang');
		$this->load->view('brg_jadi', $this->data);
	}

	public function input_brg_jadi()
	{
		$id_brg = $_POST['id_brg'];
		$id_peng = $this->session->userdata('id_log');
		$nm_brg = $_POST['nm_brg'];
		$stok_brg = $_POST['stok_brg'];
		$satuan_brg = $_POST['satuan_brg'];
		$data = array('id_barang' => $id_brg, 'id_user' => $id_peng, 'nama_barang' => 		
					$nm_brg, 'stok_barang' => $stok_brg, 'satuan' => $satuan_brg);
		$insert = $this->model_dis->tambah_user('stok_barang', $data);
		if($insert > 0){		
			redirect('welcome/hal_brg_jadi');
		}else{
			echo 'Gagal Input'; 
		}
	}

	public function update_brg_jadi($id)
	{
		$id_brg = $_POST['id_brg'];
		$id_peng = $this->session->userdata('id_log');
		$nm_brg = $_POST['nm_brg'];
		$stok_brg = $_POST['stok_brg'];
		$satuan_brg = $_POST['satuan_brg'];
		$data = array('id_barang' => $id_brg, 'id_user' => $id_peng, 'nama_barang' => 		
					$nm_brg, 'stok_barang' => $stok_brg, 'satuan' => $satuan_brg);
		$edit = $this->model_dis->editData3('stok_barang', $data,$id);
		if($edit > 0){		
			redirect('welcome/hal_brg_jadi');
		}else{
			echo 'Gagal Input'; 
		}
	}

	public function hal_pesanan()
	{
		$this->data['hasil'] = $this->model_dis->getUser('pesanan');
		$this->load->view('pesanan', $this->data);
	}

	public function input_pesanan()
	{
		$id_peng = $this->session->userdata('id_log');
		$id_brg = $_POST['id_brg'];
		$nm_brg = $_POST['nm_brg'];
		$jumlah = $_POST['jml'];
		$harga = $_POST['harga'];
		$tanggal = $_POST['tgl'];
		$data = array('id_user' => $id_peng,'id_produk' => $id_brg,'nama_produk' => 		
					$nm_brg, 'jumlah' => $jumlah, 'harga' => $harga, 'tanggal' => $tanggal);
		$insert = $this->model_dis->tambah_user('pesanan', $data);
		if($insert > 0){	
			redirect('welcome/hal_pesanan');
		}else{
			echo 'Gagal Input'; 
		}
	}

	public function update_pesanan($id)
	{
		$id_peng = $this->session->userdata('id_log');
		$id_brg = $_POST['id_brg'];
		$nm_brg = $_POST['nm_brg'];
		$jumlah = $_POST['jml'];
		$harga = $_POST['harga'];
		$tanggal = $_POST['tgl'];
		$data = array('id_user' => $id_peng,'id_produk' => $id_brg,'nama_produk' => 		
					$nm_brg, 'jumlah' => $jumlah, 'harga' => $harga, 'tanggal' => $tanggal);
		$edit = $this->model_dis->editData4('pesanan', $data,$id);
		if($edit > 0){	
			redirect('welcome/hal_pesanan');
		}else{
			echo 'Gagal Input'; 
		}
	}

	public function hal_profile()
	{
		$this->load->view('profile');
	}

	public function material()
	{
		$this->load->view('input_material');
	}

	public function pemasok()
	{
		$this->load->view('input_pemasok');
	}

	public function brg_jadi()
	{
		$this->load->view('input_brg_jadi');
	}

	public function pesanan()
	{
		$this->load->view('input_pesanan');	
	}

	public function insert()
	{
		$nama = $_POST['nama'];
		$email = $_POST['email'];
		$hp = $_POST['hp'];
		$id = $_POST['id'];
		$hp = $_POST['hp'];
		$pass = $_POST['password'];
		$data = array('nama_user' => $nama, 'email' => $email, 'no_hp' => 		
					$hp, 'username' => $id, 'password' => $pass);
		$insert = $this->model_dis->tambah_user('user', $data);
		if($insert > 0){
			$this->session->set_flashdata('sukses','Pendaftaran sukses, silahkan masuk...');
			redirect('welcome/form_daftar');
		}else{
			echo 'Gagal Daftar';
		}
	}

	public function login()
	{
		$namaPeng = $this->session->userdata('nama');
		$user = $this->input->post('username',true);
		$kode = $this->input->post('password',true);
		$cek = $this->model_dis->proses_login($user,$kode);
		$hasil = count($cek);
			if($hasil > 0){
				$log = $this->db->get_where('user', array('username' =>$user, 'password' => $kode))->row();
				$ses = array('logged_in' => true,
				'nama' => $log -> nama_user,
				'id_log' => $log -> id_user);
				$this->session->set_userdata($ses);
				redirect('welcome/hal_beranda');}
			elseif($user == '' && $kode == '')
			{
				$this->session->set_flashdata('error','User Id dan Password tidak boleh kosong!!!');
				redirect('welcome/index');
			} 
		else{
			$this->session->set_flashdata('gagal','User Id dan Password yang dimasukan salah!!!');
			redirect('welcome/index');
			}
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('welcome/index');
	}

	public function delete($id)
	{
		$hapus = $this->model_dis->hapusData('stok_material',$id);
		if($hapus > 0){
			redirect('welcome/hal_material');

		}else{
			echo 'Gagal Disimpan';
		}
	}

	public function delete_2($id)
	{
		$hapus = $this->model_dis->hapusData2('stok_barang',$id);
		if($hapus > 0){
			redirect('welcome/hal_brg_jadi');

		}else{
			echo 'Gagal Disimpan';
		}
	}

	public function delete_3($id)
	{
		$hapus = $this->model_dis->hapusData3('pemasok',$id);
		if($hapus > 0){
			redirect('welcome/hal_pemasok');

		}else{
			echo 'Gagal Disimpan';
		}
	}

	public function delete_4($id)
	{
		$hapus = $this->model_dis->hapusData4('pesanan',$id);
		if($hapus > 0){
			redirect('welcome/hal_pesanan');

		}else{
			echo 'Gagal Disimpan';
		}
	}

	public function form_edit_material($id)
	{
		$this->data['dataEdit'] = $this->model_dis->dataEdit('stok_material',$id);
		$this->load->view('edit_material', $this->data);
	}

	public function form_edit_pemasok($id)
	{
		$this->data['dataEdit2'] = $this->model_dis->dataEdit2('pemasok',$id);
		$this->load->view('edit_pemasok', $this->data);
	}

	public function form_edit_brg($id)
	{
		$this->data['dataEdit3'] = $this->model_dis->dataEdit3('stok_barang',$id);
		$this->load->view('edit_brg_jadi', $this->data);
	}

	public function form_edit_pesanan($id)
	{
		$this->data['dataEdit4'] = $this->model_dis->dataEdit4('pesanan',$id);
		$this->load->view('edit_pesanan', $this->data);
	}

	public function pencarian()
	{
		$cari = $this->input->post('isi', true);
		$this->db->like('nama_produk',$cari);
		$this->data['hasil'] = $this->model_dis->getUser('stok_material');
		$this->load->view('material', $this->data);
	}

	public function pencarian2()
	{
		$cari = $this->input->post('isi', true);
		$this->db->like('nama_pemasok',$cari);
		$this->data['hasil'] = $this->model_dis->getUser('pemasok');
		$this->load->view('pemasok', $this->data);
	}

	public function pencarian3()
	{
		$cari = $this->input->post('isi', true);
		$this->db->like('nama_barang',$cari);
		$this->data['hasil'] = $this->model_dis->getUser('stok_barang');
		$this->load->view('brg_jadi', $this->data);
	}

	public function pencarian4()
	{
		$cari = $this->input->post('isi', true);
		$this->db->like('nama_produk',$cari);
		$this->data['hasil'] = $this->model_dis->getUser('pesanan');
		$this->load->view('pesanan', $this->data);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */