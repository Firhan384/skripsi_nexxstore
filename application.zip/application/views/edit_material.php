<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Datindo Inventory System</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/style.css') ?>">

	
</head>
<body>

<div class="header">
	<div class="header-dis">
		Datindo Inventory System	
	</div>

	
	<div class="header-right">

		<a href="<?php echo site_url('welcome/form_daftar') ?>">Daftar</a>
	</div>

	<div class="header-center">
		<?php $this->session->userdata('logged_in') ?>
        <?php $namaPeng = $this->session->userdata('nama'); ?>
        <?php echo $namaPeng ?>
	</div>
</div>

<div class="section">
	<div class="menu-left">
		<ul>
			<li><a href="<?php echo site_url('welcome/hal_beranda') ?>">Beranda</a></li>
			<li>Material
				<ul>
					<li><a href="<?php echo site_url('welcome/hal_material') ?>">Stok Material</a></li><br/>
					<li><a href="<?php echo site_url('welcome/hal_pemasok') ?>">Pemasok</a></li>
				</ul>
			</li>
			<li>Barang Jadi
				<ul>
					<li><a href="<?php echo site_url('welcome/hal_brg_jadi') ?>">Stok Barang Jadi</a></li><br/>
					<li><a href="<?php echo site_url('welcome/hal_pesanan') ?>">Pemesanan Barang</a></li>
				</ul>
			</li>
			<li><a href="<?php echo site_url('welcome/hal_profile') ?>">Profile</a></li>
			<li style="margin-left: 5%;"><a href="<?php echo site_url('welcome/logout') ?>">Keluar</a></li>
		</ul>
	</div>

	<div class="bag-menu">
		<div class="input-material">
			
			<?php if($dataEdit){
				$id_prod = $dataEdit->id_produk;
				$nama_produk = $dataEdit->nama_produk;
				$stok = $dataEdit->stok;
				$satuan = $dataEdit->satuan;
			}else{
				$id_prod = "";
				$nama_produk = "";
				$stok = "";
				$satuan = "";
			} ?>

		<form method="post" action="<?php echo site_url('welcome/update_material/'.$id_prod) ?>">
            Id Produk<br />
            <input type="text" name="id_prod" value="<?php echo $id_prod ?>" /><br /><br />
            Nama Produk<br />
            <input type="text" name="nm_produk" value="<?php echo $nama_produk ?>" style="width:40%;" /><br /><br/>
            Stok <br />
            <input type="number" name="stok" value="<?php echo $stok ?>" style="width:10%;" /><br /><br/>
            Satuan<br />
            <input type="text" name="satuan" value="<?php echo $satuan ?>" /><br /><br />
            <input type="submit" name="simpan" value="Simpan" style="height:30px; width:10%;" />
       	</form>

		</div>
	</dziv>
</div>

<div class="footer">
	2018 &copy; PT. Datindo Image Werks
</div>

</body>
</html>