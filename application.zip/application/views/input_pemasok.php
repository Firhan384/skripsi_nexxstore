<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Datindo Inventory System</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/style.css') ?>">

	
</head>
<body>

<div class="header">
	<div class="header-dis">
		Datindo Inventory System	
	</div>

	
	<div class="header-right">

		<a href="<?php echo site_url('welcome/form_daftar') ?>">Daftar</a>
	</div>

	<div class="header-center">
		<?php $this->session->userdata('logged_in') ?>
        <?php $namaPeng = $this->session->userdata('nama'); ?>
        <?php echo $namaPeng ?>
	</div>
</div>

<div class="section">
	<div class="menu-left">
		<ul>
			<li><a href="<?php echo site_url('welcome/hal_beranda') ?>">Beranda</a></li>
			<li>Material
				<ul>
					<li><a href="<?php echo site_url('welcome/hal_material') ?>">Stok Material</a></li><br/>
					<li><a href="<?php echo site_url('welcome/hal_pemasok') ?>">Pemasok</a></li>
				</ul>
			</li>
			<li>Barang Jadi
				<ul>
					<li><a href="<?php echo site_url('welcome/hal_brg_jadi') ?>">Stok Barang Jadi</a></li><br/>
					<li><a href="<?php echo site_url('welcome/hal_pesanan') ?>">Pemesanan Barang</a></li>
				</ul>
			</li>
			<li><a href="<?php echo site_url('welcome/hal_profile') ?>">Profile</a></li>
			<li style="margin-left: 5%;"><a href="<?php echo site_url('welcome/logout') ?>">Keluar</a></li>
		</ul>
	</div>

	<div class="bag-menu">
		<div class="input-material">
			
		<form method="post" action="<?php echo site_url('welcome/input_pemasok') ?>">
            Id Pemasok<br />
            <input type="text" name="id_pemasok" /><br /><br />
            Nama Pemasok<br />
            <input type="text" name="nm_pemasok" style="width:40%;" /><br /><br/>
            Alamat <br />
            <input type="text" name="almt" style="width:60%;" /><br /><br/>
            Email<br />
            <input type="text" name="email" style="width:40%;" /><br /><br />
            No Telepon<br />
            <input type="text" name="no_telp" style="width:30%;" /><br /><br />
            <input type="submit" name="simpan" value="Simpan" style="height:30px; width:10%;" />
       	</form>

		</div>
	</div>
</div>

<div class="footer">
	2018 &copy; PT. Datindo Image Werks
</div>

</body>
</html>