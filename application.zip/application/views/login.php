<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Datindo Inventory System</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/style.css') ?>">

	
</head>
<body>

<div class="header">
	<div class="header-dis">
		Datindo Inventory System	
	</div>

</div>

<div class="section">
	<div class="section-login">
		<div class="masuk">
			Masuk Dengan Akun Anda!
		</div>

		<form method="POST" action="<?php echo site_url('welcome/login') ?>">
			<input type="text" name="username" placeholder="Username"><br/>
			<input type="password" name="password" placeholder="Password"><br/><br/>
			<input type="submit" name="masuk" value="Masuk" style="padding:0px; width:20%; margin-left:42%;">
		</form>
		<br><br>
		<div style="text-align:center; font-size:20px; height:30px; color:#8B0000; font-weight:bold; font-style:italic;
            			 width:100%;">
            <?php echo $this->session->flashdata('error') ?>
            <?php echo $this->session->flashdata('gagal') ?>
            </div>
	</div>
</div>

<div class="footer">
	2018 &copy; PT. Datindo Image Werks
</div>

</body>
</html>