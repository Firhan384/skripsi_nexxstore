<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Datindo Inventory System</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/style.css') ?>">

	
</head>
<body>

<div class="header">
	<div class="header-dis">
		Datindo Inventory System	
	</div>

	<div class="header-right">
		<a href="<?php echo site_url('welcome/form_daftar') ?>">Daftar</a>
	</div>

	<div class="header-center">
		<?php $this->session->userdata('logged_in') ?>
        <?php $namaPeng = $this->session->userdata('nama'); ?>
        <?php echo $namaPeng ?>
	</div>
</div>

<div class="section">
	<div class="menu-left">
		<ul>
			<li><a href="<?php echo site_url('welcome/hal_beranda') ?>">Beranda</a></li>
			<li>Material
				<ul>
					<li><a href="<?php echo site_url('welcome/hal_material') ?>">Stok Material</a></li><br/>
					<li><a href="<?php echo site_url('welcome/hal_pemasok') ?>">Pemasok</a></li>
				</ul>
			</li>
			<li>Barang Jadi
				<ul>
					<li><a href="<?php echo site_url('welcome/hal_brg_jadi') ?>">Stok Barang Jadi</a></li><br/>
					<li><a href="<?php echo site_url('welcome/hal_pesanan') ?>">Pemesanan Barang</a></li>
				</ul>
			</li>
			<li><a href="<?php echo site_url('welcome/hal_profile') ?>">Profile</a></li>
			<li style="margin-left: 5%;"><a href="<?php echo site_url('welcome/logout') ?>">Keluar</a></li>
		</ul>
	</div>

	<div class="bag-menu">
		<div class="isi-menu">
			<div class="isi-menu-kiri">
				<a href="<?php echo site_url('welcome/material') ?>">Input Material</a>
			</div>

			<div class="content-menu">
				<div class="content-menu-cari">
					<form method="post" action="<?php echo site_url('welcome/pencarian') ?>">
						<input type="text" name="isi" />
               		    <input type="submit" name="cari" value="Cari" style="width:15%; height:25px; padding-left:0px;" />
					</form>
				</div>

				<table cellspacing="0px;">
                    	<tr style="font-size:18px; font-weight:bold;">
                        	<td width="7%;">No</td>
                        	<td width="20%;">Kode Produk</td>
                            <td width="40%;">Nama Produk</td>
                            <td width="10%;">Stok</td>
                            <td width="10%;">Satuan</td>
                            <td>Option</td>
                        </tr>

                        <?php
						$no = 1; 
						foreach($hasil as $r) { ?>	
						<tr>
							<td><?php echo $no++ ?></td>
							<td><?php echo $r['id_produk'] ?></td>
							<td><?php echo $r['nama_produk'] ?></td>
							<td><?php echo $r['stok'] ?></td>
							<td><?php echo $r['satuan'] ?></td>
							<td>
							<a href="<?php echo site_url('welcome/form_edit_material/'.$r['id_produk']) ?>" style="color: #8B0000;">Edit</a> ||
							<a href="<?php echo site_url('welcome/delete/'.$r['id_produk']) ?>" onclick="return confirm('Yakin ingin menghapus data ?')" style="color: #8B0000;">Hapus</a>
							</td>
						</tr>

						<?php } ?>
                </table>
			</div>
		</div>
	</div>
</div>

<div class="footer">
	2018 &copy; PT. Datindo Image Werks
</div>

</body>
</html>