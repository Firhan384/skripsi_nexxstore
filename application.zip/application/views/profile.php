<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Datindo Inventory System</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/style.css') ?>">

	
</head>
<body>

<div class="header">
	<div class="header-dis">
		Datindo Inventory System	
	</div>

	<div class="header-right">
		<a href="<?php echo site_url('welcome/form_daftar') ?>">Daftar</a>
	</div>

	<div class="header-center">
		<?php $this->session->userdata('logged_in') ?>
        <?php $namaPeng = $this->session->userdata('nama'); ?>
        <?php echo $namaPeng ?>
	</div>
</div>

<div class="section">
	<div class="menu-left">
		<ul>
			<li><a href="<?php echo site_url('welcome/hal_beranda') ?>">Beranda</a></li>
			<li>Material
				<ul>
					<li><a href="<?php echo site_url('welcome/hal_material') ?>">Stok Material</a></li><br/>
					<li><a href="<?php echo site_url('welcome/hal_pemasok') ?>">Pemasok</a></li>
				</ul>
			</li>
			<li>Barang Jadi
				<ul>
					<li><a href="<?php echo site_url('welcome/hal_brg_jadi') ?>">Stok Barang Jadi</a></li><br/>
					<li><a href="<?php echo site_url('welcome/hal_pesanan') ?>">Pemesanan Barang</a></li>
				</ul>
			</li>
			<li><a href="<?php echo site_url('welcome/hal_profile') ?>">Profile</a></li>
			<li style="margin-left: 5%;"><a href="<?php echo site_url('welcome/logout') ?>">Keluar</a></li>
		</ul>
	</div>

	<div class="bag-menu">
		<div class="			<br/>isi-menu">
			<div class="profile-kiri">
				<img src="<?php echo base_url('upload/picture2.jpg') ?>">
			</div>

			<div class="profile-kanan">
			<p> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
			PT. Datindo Image Werks berdiri sejak tahun 1992 dan kami bergerak dalam bidang percetakan plastic card, digital printing, dan offset printing. Selama kurun waktu 18 tahun kami melayani berbagai jenis perusahaan di Indonesia, baik instansi pemerintah maupun instansi swasta. </p>
			<br/>
            <p> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            Adapun produk dan jasa yang kami hasilkan adalah seperti : ID Card, Kartu ATM, Member Card, Kartu Pasien, Mesin Cetak Kartu & Suppliesnya, dan di bidang Digital/Offset Printing seperti : Kartu nama, Banner, Spanduk, Neon Box, Brosur, Cutting Sticker, Manual Book, dan lainnya.</p>
			</div>
		</div>
	</div>
</div>

<div class="footer">
	2018 &copy; PT. Datindo Image Werks
</div>

</body>
</html>